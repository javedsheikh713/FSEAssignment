import { Component } from '@angular/core';

@Component({
    selector: 'player-component',
    templateUrl: './player.component.html'
    
  })
export class PlayerComponent {

}