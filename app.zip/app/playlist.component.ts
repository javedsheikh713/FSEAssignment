import { Component } from '@angular/core';

@Component({
    selector: 'playlist-component',
    templateUrl: './playlist.component.html'
    
  })

export class PlaylistComponent {

}