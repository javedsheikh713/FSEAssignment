import { Component, OnInit } from '@angular/core';
import { PlayItem } from './playItem';
import { PlayItemService } from './services/playItem.service';

@Component({
  selector: 'addvideo-root',
  templateUrl: './addvideo.component.html'
  
})
export class AddVideoComponent implements OnInit{

  constructor(private playItemService:PlayItemService){

  }

  ngOnInit(){
  
    this.playItemService.findAllPlayList().then((res:Array<PlayItem>)=> {
      this.playItems = res
   })
  }
 
  playItems: Array<PlayItem> = [];
  urlError:String;
  titleError:String;
    
  public addVideo(title:string,url:string){
    
    if(title ==null){
      this.titleError='Please enter Title value';
      return null;
    }

    if(url ==null){
      this.urlError='Please enter URL value';
      return null;
    }
    
    let body = {id:0,title:title, url:url,status:'added',approved:0,likes:0,unlike:0}

    this.playItemService.addVideo(body).then( (res:any)=> {
      this.findAllPlayList();
    })
   
    alert('Successfully added');
  }

  public approveVideo(playItem:PlayItem){
    
    playItem.approved=1;
    this.playItemService.editVideo(playItem);
    this.findAllPlayList();
  }
  public editVideo(playItem:PlayItem){
    
    this.playItemService.addVideo(playItem);
  }

  public deleteVideo(id:number){
    
    this.playItemService.deleteVideo(id).then( (res:any)=> {
      this.findAllPlayList();
    })
   
  }

  public findAllPlayList(){

    this.playItemService.findAllPlayList().then((res:Array<PlayItem>)=> {
           
      this.playItems = res;
     
    })
   }
  
}
