import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PlayerComponent } from './player.component';
import { ControlerComponent } from './controler.component';
import { PlaylistComponent } from './playlist.component';

@NgModule({
  declarations: [
    AppComponent,
    PlayerComponent,
    ControlerComponent,
    PlaylistComponent 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
