import { Component, OnInit } from '@angular/core';
import { PlayItem } from './playItem';
import { PlayItemService } from './services/playItem.service';

@Component({
  selector: 'addvideo-root',
  templateUrl: './addvideo.component.html'
  
})
export class AddVideoComponent implements OnInit{

  constructor(private playItemService:PlayItemService){

  }

  ngOnInit(){
  
  }
 
    
  public addVideo(title:string,url:string){
    
    
    let body = {id:0,title:title, url:url,status:'added',approved:0,likes:0,unlike:0}

    this.playItemService.addVideo(body);
    alert('Successfully added');
  }
  
}
