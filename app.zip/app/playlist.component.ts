import { Component, OnInit } from '@angular/core';
import { PlayItemService } from './services/playItem.service';
import { PlayItem } from './playItem';

declare function run(link): any;
@Component({
    selector: 'playlist-component',
    templateUrl: './playlist.component.html'
    
  })

export class PlaylistComponent implements OnInit{

    constructor(private playItemService:PlayItemService){

    }

    ngOnInit(){
        this.playItemService.findAllPlayList().then((res:Array<PlayItem>)=> {
            console.log(res)
            this.playItems = res
          })
        }

        playItems: Array<PlayItem> = []

        public run1(link){
           // alert(link);
          run(link);
        }
}