import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


const baseUrl: string = 'http://localhost:3000/youtube/'


@Injectable()
export class PlayItemService {
    
    constructor(private http: HttpClient) { }


    addCourse(course: any){
        return this.http.post(baseUrl, course).toPromise()
    }

    deleteCourse(id: number){
        return this.http.delete(baseUrl + id).toPromise()
    }

    findAllPlayList(){
        return this.http.get(baseUrl).toPromise()
    }

}