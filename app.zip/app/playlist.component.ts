import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { PlayItemService } from './services/playItem.service';
import { PlayItem } from './playItem';

declare function run(link): any;
@Component({
    selector: 'playlist-component',
    templateUrl: './playlist.component.html'
    
  })

export class PlaylistComponent{

  @Input() playItems: Array<PlayItem> = [];
  @Output() clickedOnPlaylist = new EventEmitter<number>();

        public run1(playItem:PlayItem){
           // alert(link);
          
          run(playItem.url);
          this.clickedOnPlaylist.emit(playItem.id);
        }

      
}