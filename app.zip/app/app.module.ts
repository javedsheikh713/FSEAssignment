import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PlayerComponent } from './player.component';
import { ControlerComponent } from './controler.component';
import { PlaylistComponent } from './playlist.component';
import { PlayItemService } from './services/playItem.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    PlayerComponent,
    ControlerComponent,
    PlaylistComponent 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule
  ],
  providers: [PlayItemService],
  bootstrap: [AppComponent]
})
export class AppModule { }
