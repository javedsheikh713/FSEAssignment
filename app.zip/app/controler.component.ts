import { Component } from '@angular/core';

@Component({
    selector: 'controler-player',
    templateUrl: './controler.component.html'
    
  })
  
export class ControlerComponent{

}